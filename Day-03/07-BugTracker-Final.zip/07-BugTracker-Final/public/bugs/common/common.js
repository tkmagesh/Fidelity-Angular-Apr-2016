angular.module("bugTrackerApp.common",[]);
