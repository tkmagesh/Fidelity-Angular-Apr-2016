angular
	.module("bugTrackerApp.common")
	.value('appDefaults', {
		bugName : '[Default bug]',
		trimLength : 30,
		trailText : '***'
	});